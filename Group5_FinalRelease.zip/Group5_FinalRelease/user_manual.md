Welcome to Climate Change and You, the choropleth-focused multi-visualization of various atmospheric indicators of climate change across the world. Zoom, pan, and move through the years for six maps, each associated with its own climate change indicator. This user manual will detail what the components of this directory are, and how to use them. 

# ***user_manual.md***
You're reading it!

# ***output.html***
This is the fully finished product, compiled into an html document, that can be clicked on, pulling up the product on a new tab in your browser. If you are just trying to view the finished product, simply use this. Otherwise, see the code directory's section for the intermediate steps. 

# ***datasets***
This folder holds all of our in-used datasets throughout this project.

## ***original***
These are the original data sets that were encoded into our visualizations.

### ***IMF_climate_disasters.csv***
This dataset provided by the IMR (Sourced from https://climatedata.imf.org/datasets/b13b69ee0dde43a99c811f592af4e821/about) provides the climate disaster counts for countries across the world. "Climate Disaster" refers to droughts, extreme temperatures, floods, landslides, storms, and wildfires. 

### ***OWID_emissions.csv***
This dataset provided by Our World in Data (Sourced from https://github.com/owid/co2-data?tab=readme-ov-file) is a collection of various emissions statistics, though we only worked with CO2 emissions and CO2 emissions per capita. 

### ***Indicator_3_1_Climate_Indicators_Annual_Mean_Global_Surface_Temperature_577579683071085080.csv***
This dataset procided by the IMF (Sourced from https://climatedata.imf.org/datasets/4063314923d74187be9596f10d034914_0/about) is a set of annual estimates for temperature change with respect to mean. This was used to find the temperature anomalies. 

## ***1st step processing***
This folder is made of output of our cumulative_transform.ipynb jupiter notebook, which reduced OWID_emissions.csv to only the attributes we wanted, as well as created cumulative datasets from the existing ones. Essentially our first phase of data processing. Some names were changed when moving forward with the 2nd step of processing, making some incompatibility issues. And so we do not recommend trying to reprocess the data from this step. 

One note is temperature_anomaly_annual.csv, which was produced from Indicator_3_1_Climate_Indicators_Annual_Mean_Global_Surface_Temperature_577579683071085080.csv by deleting some columns in the equivalent excel sheet and then converting it back into a csv. 

## ***2nd step processing***
This folder is made of output of our predict.ipynb jupiter notebook, and are the files directly used for our beta.py code. This second phase creates predictions for years beyond 2021. 

# ***code***
This folder holds all of our code. 

## ***beta.py***
This is our actual code that creates and opens output.html in a tab. 

To run it, first make sure of a couple of things:
- You will need to install the latest version of Python (3.10 or later should work)
- You will need to install numpy, plotly, and pandas (Such as by `pip install numpy plotly pandas`)
- You will need beta.py and all of the csv files in datasets/2nd step processing to be in the same directory.

Then, you may run it as you would any other python program: `python beta.py` or `python3 beta.py`. This will simultaneously create an output.html file in the directory, as well as, pull up the visualization on your own tab. 

## ***notebooks***
This folder holds our Jupiter Notebooks, which were used to preprocess the data. 

Of course, you need Jupiter Notebooks to be installed before trying to use them

### ***cumulative_transform.ipynb***
This was the notebook used for our first phase of processing. 

This notebook assumes that IMF_climate_disasters.csv, OWID_emissions.csv, and Indicator_3_1_Climate_Indicators_Annual_Mean_Global_Surface_Temperature_577579683071085080.csv are in a different folder. 

More specifically, it assumes that the datasets are in a folder called datasets that is on the same level as the parent folder of cumulative_transform.ipynb's parent folder (it uses `..\..\datasets\dataset.csv` as the relative path). 

This means that you can either put the datasets in another folder on the same level as Group5_FinalRelease, or to create a folder within notebooks to put cumulative_transform into. Either way, after you do so, you can load cumulative_transform into Jupiter Notebooks and run it.

### ***predict.ipynb***
This is the 2nd data processing step's Jupiter Notebook, which adds additional entries for future years, based on the previous ten year's values. 

This notebook assumes that predict.ipynb are in the same directory as:
- co2_annual_data.csv
- co2_cumulative_data.csv
- co2_per_capita_cumulative_data.csv
- co2_per_capita_data.csv
- disasters_cumulative.csv
- temperature_anomaly_annual.csv

So just put this notebook into the 1st step processing folder, and run it in Jupiter Notebooks. 

# ***Additional Notes***
As an aside, we also kept a github amongst ourselves, if you seek any intermediate pushes of the code: https://github.com/mferretti314/436-dataviz/tree/main